# lab-manager
AI Chatbot để tra cứu và thống kê vật tư, hóa chất phòng thí nghiệm
